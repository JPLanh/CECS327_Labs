var searchData=
[
  ['writemetadata',['writeMetaData',['../classDFS.html#ae97c5b386f9d638a2ca9ebd79665bb25',1,'DFS.writeMetaData(InputStream stream)'],['../classDFS.html#af91de8d4036503ca5b0913d69b4f2cae',1,'DFS.writeMetaData(String getString)']]]
];
