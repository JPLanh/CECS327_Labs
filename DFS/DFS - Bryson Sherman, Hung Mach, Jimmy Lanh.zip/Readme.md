# Distributed File System

# To run
In order to execute the file we need to execute it through command (atleast on windows)

## to compile <br/>
go to the directory <br/>
javac classpath ".;./javax.json-1.1.jar" Chord.java ChordMessageInterface.java Client.java DFS.java FileStream.java

## Command to run, atleast on window machine <br/>
java -classpath .;./javax.json-1.1.jar Client {port number} <br/>
change the ";" in the command for a UNIX based machine (Linux, MAC) <br/>
To be consitent with the peers we are using 23245 <br/>


# Notice
The libaries for the Json we need for this project has been included in the lib folder,
Add the javax.json.1-1.jar as a library in your project to start working
