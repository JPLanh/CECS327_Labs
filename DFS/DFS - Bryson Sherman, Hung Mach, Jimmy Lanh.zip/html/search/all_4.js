var searchData=
[
  ['getmetadata',['getMetaData',['../classDFS.html#aa7862e7d52d5b1b74874890840a886f9',1,'DFS']]]
];
