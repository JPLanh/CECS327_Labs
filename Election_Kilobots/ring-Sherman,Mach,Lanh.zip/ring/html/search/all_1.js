var searchData=
[
  ['enqueue_5fmessage',['enqueue_message',['../ring_8c.html#af31e097898d9b7b49e904cb3c9958afd',1,'ring.c']]],
  ['exists_5fnearest_5fneighbor',['exists_nearest_neighbor',['../ring_8c.html#a421bd0c8e972c872a4c101c7fe2776db',1,'ring.c']]]
];
