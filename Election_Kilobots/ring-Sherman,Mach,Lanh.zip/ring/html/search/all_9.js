var searchData=
[
  ['userdata',['USERDATA',['../structUSERDATA.html',1,'']]]
];
