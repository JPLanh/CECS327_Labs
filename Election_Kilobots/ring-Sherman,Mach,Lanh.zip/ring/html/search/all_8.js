var searchData=
[
  ['send_5felection',['send_election',['../ring_8c.html#ab9082108a5add8649dfe4d65c7d7b676',1,'ring.c']]],
  ['send_5fjoining',['send_joining',['../ring_8c.html#a1695dcc0c6a920317d739886e3266093',1,'ring.c']]],
  ['send_5fsharing',['send_sharing',['../ring_8c.html#a95a8f45823e9116b153d0b1f7eaa6201',1,'ring.c']]],
  ['set_5fmotion',['set_motion',['../ring_8c.html#a88524e838112e1905cc3f74b0735ae71',1,'ring.c']]],
  ['setup',['setup',['../ring_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'ring.c']]],
  ['smooth_5fset_5fmotors',['smooth_set_motors',['../ring_8c.html#a540b8ce2367b2cf4b32c8b8c7e9642fc',1,'ring.c']]]
];
