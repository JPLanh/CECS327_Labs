var searchData=
[
  ['enumptr',['enumPtr',['../classQTstyle__Test.html#a973a4566c9a036f4eca508ba5fe80dcb',1,'QTstyle_Test']]],
  ['enumvar',['enumVar',['../classQTstyle__Test.html#adb265d815b43f1f7f0de0e8b8852a5d0',1,'QTstyle_Test']]]
];
