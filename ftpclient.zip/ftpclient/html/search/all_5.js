var searchData=
[
  ['handler',['handler',['../classQTstyle__Test.html#a79dd4e5498f09057775a819d911349e2',1,'QTstyle_Test']]]
];
