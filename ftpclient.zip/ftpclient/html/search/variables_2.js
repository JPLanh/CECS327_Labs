var searchData=
[
  ['publicvar',['publicVar',['../classQTstyle__Test.html#aabf7b2e9ed83ea44aca4d213baae06d3',1,'QTstyle_Test']]]
];
