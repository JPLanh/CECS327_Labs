var searchData=
[
  ['notify',['notify',['../classChord.html#a4de8b8464782dd96d88deeb35b2f27a2',1,'Chord']]]
];
