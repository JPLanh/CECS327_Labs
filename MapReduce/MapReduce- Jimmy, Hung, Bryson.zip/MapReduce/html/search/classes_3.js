var searchData=
[
  ['mapper',['Mapper',['../classMapper.html',1,'']]],
  ['mapreduceinterface',['MapReduceInterface',['../interfaceMapReduceInterface.html',1,'']]]
];
