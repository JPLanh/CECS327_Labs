var indexSectionsWithContent =
{
  0: "acdefghijlmnprstw",
  1: "cdfm",
  2: "acdefghijlmnprstw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

