var searchData=
[
  ['read',['read',['../classDFS.html#a2b0807ccc73aba1957c65ca66d740635',1,'DFS.read(String fileName, long guidGet)'],['../classDFS.html#a38d1d750833a304a2d09541820cd5108',1,'DFS.read(String fileName, int pageNumber)']]],
  ['readmetadata',['readMetaData',['../classDFS.html#a4b89b90a4bc23ed5a93a30ac55a2f59d',1,'DFS']]],
  ['reduce',['reduce',['../classMapper.html#aa7a0fa5332941b8a11405990e7891361',1,'Mapper']]],
  ['reducecontext',['reduceContext',['../classChord.html#a8e76cb9bff18d87c9a2971839034a18e',1,'Chord']]],
  ['runmapreduce',['runMapReduce',['../classDFS.html#a29cbe4bc9381022a65a354e469935657',1,'DFS']]]
];
